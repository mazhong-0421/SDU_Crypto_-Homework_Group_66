import secrets
import string
from gmssl import sm3
import time

def generate_random_message(length=16):
    characters = string.ascii_letters + string.digits + string.punctuation
    random_bytes = secrets.token_bytes(length)
    random_message = ''.join(characters[b % len(characters)] for b in random_bytes)
    return random_message

def hash_message(message):
    return sm3.Hash_sm3(message)

def rho_method_attack():
    hash_table = {}
    collision_found = False
    collision_attempts = 0

    start_time = time.time()

    while not collision_found:
        message = generate_random_message()
        hash_value = hash_message(str(message))

        if hash_value in hash_table:
            original_message = hash_table[hash_value]
            if verify_collision(original_message, message):
                collision_found = True
                end_time = time.time()
                print("碰撞已找到！")
                print("原始消息:", original_message)
                print("碰撞消息:", message)
                print("尝试次数:", collision_attempts)
                print("测试时间:", end_time - start_time, "秒")

        hash_table[hash_value] = message
        collision_attempts += 1

def verify_collision(original_message, colliding_message):
    original_hash = hash_message(original_message)
    colliding_hash = hash_message(colliding_message)
    return original_hash == colliding_hash and original_message != colliding_message

rho_method_attack()
