import hashlib

prime_modulus = 863
# 数据记录
data_records = {
    "user1": "password1",
    "user2": "password2",
    "user3": "password3"
}

# 密钥
b = 7  # 服务器的私密参数

# 创建 key-value 表
key_value_table = {}

# 处理数据信息
for username, password in data_records.items():
    hi = hashlib.sha256((username + password).encode()).hexdigest()
    ki = hi[:2]
    vi = pow(int(hi, 16),b,prime_modulus)
    key_value_table[ki] = vi

# 分割表为 2^16 个集合
table_sets = {}
for ki, vi in key_value_table.items():
    set_index = int(ki, 16)
    if set_index not in table_sets:
        table_sets[set_index] = set()
    table_sets[set_index].add(vi)


def prepare_data_info():
    # 创建 key-value 表
    key_value_table = {}

    # 处理数据信息
    for username, password in data_records.items():
        hi = hashlib.sha256((username + password).encode()).hexdigest()
        ki = hi[:2]
        vi = pow(int(hi, 16) , b,prime_modulus)
        key_value_table[ki] = vi
    #print(key_value_table)
    # 分割表为 2^16 个集合
    table_sets = {}
    for ki, vi in key_value_table.items():
        set_index = int(ki, 16)
        if set_index not in table_sets:
            table_sets[set_index] = set()
        table_sets[set_index].add(vi)
    #print(table_sets)

def check_username_password(username, password):
    # 用户输入的用户名和密码
    u = username
    p = password

    # 生成客户端的临时密钥
    sk = 'a'

    # 计算客户端的 key-value
    h = hashlib.sha256((u + p).encode()).hexdigest()
    k = h[:2]
    hb=pow(int(h, 16), b,prime_modulus)
    v = pow(int(h, 16), int(sk, 16),prime_modulus)
    h_=int(h, 16)%prime_modulus
    # 查找数据集
    data_set = find_data_set(k)

    # 计算 h^ab
    hab = pow(h_, int(sk, 16) * b, prime_modulus)

    # 计算 ((h^ab) ^ (a^-1)) = h^b
    hb_ = pow(hab, pow(int(sk, 16), -1, prime_modulus), prime_modulus)

    # 检查用户名和密码是否存在于数据集中
    if hb in data_set:
        return True
    else:
        return False


def find_data_set(k):
    set_index = int(k, 16)
    if set_index in table_sets:
        return table_sets[set_index]
    else:
        return set()


# 预备工作：处理数据信息
prepare_data_info()

# 示例调用
username = "user1"
password = "password1"

if check_username_password(username, password):
    print("用户名和密码存在于已泄露的数据库中。")
else:
    print("用户名和密码没有出现在已泄露的数据库中。")
