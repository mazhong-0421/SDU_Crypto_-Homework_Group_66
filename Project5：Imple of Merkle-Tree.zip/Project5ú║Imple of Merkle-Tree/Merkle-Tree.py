import hashlib
import struct

class LogEntry:
    """日志条目类，用于表示Merkle Tree中的叶节点"""

    def __init__(self, index, leaf_data):
        self.index = index
        self.leaf_data = leaf_data

    def serialize(self):
        """序列化日志条目"""
        return struct.pack(">Q", self.index) + self.leaf_data


def hash_leaf(leaf_data):
    """计算叶节点的哈希值"""
    hash_func = hashlib.sha256()
    hash_func.update(leaf_data)
    return hash_func.digest()


def hash_nodes(left_hash, right_hash):
    """计算节点的哈希值"""
    hash_func = hashlib.sha256()
    hash_func.update(left_hash)
    hash_func.update(right_hash)
    return hash_func.digest()


def construct_merkle_tree(log_entries):
    """构建Merkle Tree"""
    if len(log_entries) == 0:
        return None

    # 构建叶节点哈希列表
    leaf_hashes = [hash_leaf(entry.leaf_data) for entry in log_entries]

    # 递归构建树状结构
    tree = leaf_hashes
    while len(tree) > 1:
        next_level = []
        for i in range(0, len(tree), 2):
            left_hash = tree[i]
            if i + 1 < len(tree):
                right_hash = tree[i + 1]
            else:
                right_hash = left_hash
            node_hash = hash_nodes(left_hash, right_hash)
            next_level.append(node_hash)
        tree = next_level

    return tree[0]  # 返回根哈希


def verify_integrity(log_entries, root_hash):
    """验证数据完整性"""
    calculated_root_hash = construct_merkle_tree(log_entries)
    return calculated_root_hash == root_hash


def retrieve_modified_data(log_entries, root_hash):
    """检索被修改的数据块"""
    tree = [hash_leaf(entry.leaf_data) for entry in log_entries]
    index = 0
    while len(tree) > 1:
        left_hash = tree[index]
        right_hash = tree[index + 1] if index + 1 < len(tree) else left_hash
        parent_hash = hash_nodes(left_hash, right_hash)
        if parent_hash != root_hash[index // 2]:
            if index % 2 == 0:
                index += 1
            else:
                index -= 1
            break
        index //= 2
    modified_data = log_entries[index].leaf_data
    return modified_data


# 示例用法
log_entries = [
    LogEntry(0, b'block1'),
    LogEntry(1, b'block2'),
    LogEntry(2, b'block3'),
    LogEntry(3, b'block4')
]

root_hash = construct_merkle_tree(log_entries)
print("根哈希：", root_hash.hex())

# 修改数据块来测试检索功能
log_entries[1].leaf_data = b'modified block2'
modified_data = retrieve_modified_data(log_entries, root_hash)
print("被修改的数据块：", modified_data)


