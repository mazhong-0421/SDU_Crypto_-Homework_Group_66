import hashlib
from ecdsa import SigningKey, VerifyingKey, SECP256k1


class Multiset:
    def __init__(self):
        self.private_key = None
        self.public_key = None

    def add(self, data):
        if self.private_key is None:
            # 如果私钥不存在，则生成新的私钥和对应的公钥
            private_key = SigningKey.generate(curve=SECP256k1)
            self.private_key = private_key
            self.public_key = private_key.get_verifying_key()

        # 使用私钥对数据进行签名
        signature = self.private_key.sign(data, hashfunc=hashlib.sha256)
        return signature

    def remove(self, data, signature):
        if self.public_key is None:
            raise Exception("Multiset has not been initialized.")

        try:
            # 使用公钥验证签名是否有效
            self.public_key.verify(signature, data, hashfunc=hashlib.sha256)
            return True
        except:
            return False

    def combine(self, other_multiset):
        if not isinstance(other_multiset, Multiset):
            raise TypeError("Invalid type for 'other_multiset'. Expected Multiset.")

        if self.public_key is None or other_multiset.public_key is None:
            raise Exception("Multiset has not been initialized.")

        combined_multiset = Multiset()
        # 获取公钥的字节串表示
        pubkey1_bytes = self.public_key.to_string()
        pubkey2_bytes = other_multiset.public_key.to_string()

        # 将两个公钥的字节串进行点加法运算
        combined_public_key_bytes = self._add_public_keys(pubkey1_bytes, pubkey2_bytes)

        # 从字节串恢复公钥对象
        combined_public_key = VerifyingKey.from_string(combined_public_key_bytes, curve=SECP256k1)

        combined_multiset.public_key = combined_public_key
        return combined_multiset

    def finalize(self):
        if self.public_key is None:
            raise Exception("Multiset has not been initialized.")

        # 对公钥进行编码并计算最终哈希值
        result_hash = self.public_key.to_string()
        return result_hash

    @staticmethod
    def _add_public_keys(pubkey1_bytes, pubkey2_bytes):
        # 使用底层函数执行点加法运算
        pubkey1 = VerifyingKey.from_string(pubkey1_bytes, curve=SECP256k1)
        pubkey2 = VerifyingKey.from_string(pubkey2_bytes, curve=SECP256k1)
        point1 = pubkey1.pubkey.point
        point2 = pubkey2.pubkey.point
        combined_point = point1 + point2
        combined_pubkey_bytes = combined_point.to_bytes()
        return combined_pubkey_bytes


class HomomorphicMultiset(Multiset):
    def __init__(self):
        super().__init__()
        self.hashed_data = hashlib.sha256(b"").digest()

    def add(self, data):
        signature = super().add(data)
        self.hashed_data = hashlib.sha256(self.hashed_data + signature).digest()
        return signature

    def remove(self, data, signature):
        result = super().remove(data, signature)
        if result:
            signature_hash = hashlib.sha256(signature).digest()
            self.hashed_data = hashlib.sha256(self.hashed_data.replace(signature_hash, b"")).digest()
        return result

    def combine(self, other_multiset):
        if not isinstance(other_multiset, HomomorphicMultiset):
            raise TypeError("Invalid type for 'other_multiset'. Expected HomomorphicMultiset.")

        combined_multiset = HomomorphicMultiset()
        combined_multiset.hashed_data = hashlib.sha256(self.hashed_data + other_multiset.hashed_data).digest()
        return combined_multiset

    @staticmethod
    def homomorphic_combine(multiset1, multiset2):
        if not isinstance(multiset1, HomomorphicMultiset) or not isinstance(multiset2, HomomorphicMultiset):
            raise TypeError("Invalid type for 'multiset1' or 'multiset2'. Expected HomomorphicMultiset.")

        combined_multiset = multiset1.combine(multiset2)
        return combined_multiset

    def finalize(self):
        return self.hashed_data


# Example usage and verification of homomorphic property
multiset1 = HomomorphicMultiset()
data1 = b"data1"
signature1 = multiset1.add(data1)

multiset2 = HomomorphicMultiset()
data2 = b"data2"
signature2 = multiset2.add(data2)

is_valid1 = multiset1.remove(data1, signature1)
is_valid2 = multiset2.remove(data2, signature2)

print("Signature1 is valid:", is_valid1)
print("Signature2 is valid:", is_valid2)

combined_multiset = HomomorphicMultiset.homomorphic_combine(multiset1, multiset2)
final_hash = combined_multiset.finalize()

print("Combined Multiset Hash:", final_hash.hex())

multiset1_hash = multiset1.finalize()
multiset2_hash = multiset2.finalize()
expected_combined_hash = hashlib.sha256(multiset1_hash + multiset2_hash).digest()

if final_hash == expected_combined_hash:
    print("Homomorphic property is verified.")
else:
    print("Homomorphic property verification failed.")
