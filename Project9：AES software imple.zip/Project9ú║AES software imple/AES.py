import time
import os
import struct
class AES:

    RCon   = [0x01000000, 0x02000000, 0x04000000, 0x08000000, 0x10000000, 0x20000000, 0x40000000, 0x80000000, 0x1B000000, 0x36000000]
    S_BOX = [[0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76],
             [0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0],
             [0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15],
             [0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75],
             [0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84],
             [0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF],
             [0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8],
             [0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2],
             [0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73],
             [0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB],
             [0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79],
             [0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08],
             [0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A],
             [0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E],
             [0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF],
             [0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16]]

    def SubBytes(self, State):
        # 字节替换
        return [self.S_BOX[i][j] for i, j in
                [(_ >> 4, _ & 0xF) for _ in State]]


    def RotWord(self, _4byte_block):
        # 用于生成轮密钥的字移位
        return ((_4byte_block & 0xffffff) << 8) + (_4byte_block >> 24)

    def ShiftRows(self, S):
        # 行移位
        return [S[ 0], S[ 5], S[10], S[15],
                S[ 4], S[ 9], S[14], S[ 3],
                S[ 8], S[13], S[ 2], S[ 7],
                S[12], S[ 1], S[ 6], S[11]]


    def SubWord(self, _4byte_block):
        # 用于生成密钥的字节替换
        result = 0
        for i in range(4):
            byte = (_4byte_block >> i * 8) & 0xff
            row = (byte >> 4) & 0xf
            col = byte & 0xf
            sbox_value = self.S_BOX[row][col]
            result |= sbox_value << i * 8
        return result

    def round_key_generator(self, _16bytes_key, n):
        # 轮密钥产生
        # 将16字节的密钥拆分成五个32位的整数，并存储在列表w中
        w = [
            (_16bytes_key >> 96) & 0xFFFFFFFF,  # 右移96位得到高32位，对低32位取模
            (_16bytes_key >> 64) & 0xFFFFFFFF,  # 右移64位得到高32位，对低32位取模
            (_16bytes_key >> 32) & 0xFFFFFFFF,  # 右移32位得到高32位，对低32位取模
            _16bytes_key & 0xFFFFFFFF  # 对低32位取模
        ]

        temp = w[3]
        temp = self.SubWord(self.RotWord(temp)) ^ self.RCon[n]
        w[0] = w[0] ^ temp
        for i in range(1, 4):
            w[i] = w[i - 4] ^ w[i - 1]
        return self.num_2_16bytes(sum([w[0] << 96, w[1] << 64, w[2] << 32, w[3]]))

    def AddRoundKey(self, State, RoundKey):
        # 异或轮密钥
        return self._16bytes_xor(State, RoundKey)

    def _16bytes_xor(self, _16bytes_1, _16bytes_2):
        return [_16bytes_1[i] ^ _16bytes_2[i] for i in range(16)]

    def _16bytes2num(cls, _16bytes):
        # 16字节转数字
        return int.from_bytes(_16bytes, byteorder = 'big')

    def num_2_16bytes(cls, num):
        # 数字转16字节
        return num.to_bytes(16, byteorder = 'big')

    def get_key_list(self,key_):
        RoundKey=key_
        Key_list = []
        for i in range(1, 11):
            RoundKey_ = aes._16bytes2num(RoundKey)
            RoundKey = aes.round_key_generator(RoundKey_, i - 1)
            Key_list.append(RoundKey)
        return Key_list

    def mix_columns(self,state):
        # 用于AES算法的列混合操作
        MIX = [[0x02, 0x03, 0x01, 0x01],
                             [0x01, 0x02, 0x03, 0x01],
                             [0x01, 0x01, 0x02, 0x03],
                             [0x03, 0x01, 0x01, 0x02]]

        def mod_poly(poly, mod=0b100011011):
            # 多项式模多项式mod
            while poly.bit_length() > 8:
                poly ^= mod << poly.bit_length() - 9
            return poly

        def mul_poly(poly1, poly2):
            # 多项式相乘
            result = 0
            for index in range(poly2.bit_length()):
                if poly2 & 1 << index:
                    result ^= poly1 << index
            return result

        def matrix_mul(matrix1, matrix2):  # matrix1 = MIX_COLUMN_MATRIX  matrix2 = state
            # 用于列混合的矩阵相乘
            result = [0] * 16
            for row in range(4):
                for col in range(4):
                    for index in range(4):
                        result[row + col * 4] ^= mul_poly(matrix1[row][index], matrix2[index + col * 4])
                    result[row + col * 4] = mod_poly(result[row + col * 4])
            return result

        return matrix_mul(MIX, state)

    def encrypt(self,text,key):
        key_ = aes.num_2_16bytes(key)
        #text = aes.num_2_16bytes(text)
        Key_list = aes.get_key_list(key_)
        # print(Key_list)
        roundi = aes.AddRoundKey(text, key_)
        for i in range(9):
            roundi = aes.SubBytes(roundi)
            roundi = aes.ShiftRows(roundi)
            roundi = aes.mix_columns(roundi)
            roundi = aes.AddRoundKey(roundi, Key_list[i])
        roundi = aes.SubBytes(roundi)
        roundi = aes.ShiftRows(roundi)
        roundi = aes.AddRoundKey(roundi, Key_list[9])
        return roundi


def num_2_16bytes(num):
    return num.to_bytes(16, byteorder='big')

def encrypt_OFB(plaintext, key, iv):
    aes = AES()
    ciphertext = b''
    for i in range(len(plaintext) // 16):
        iv_copy = aes.encrypt(iv, key)
        keystream = iv_copy[:16]  # 使用完整的 IV 块作为密钥流
        ciphertext += bytes([plaintext[i * 16 + j] ^ keystream[j] for j in range(len(keystream))])

    return ciphertext


def decrypt_OFB(ciphertext, key, iv):
    aes = AES()
    plaintext = b''
    for i in range(len(ciphertext) // 16):
        iv_copy = aes.encrypt(iv, key)
        keystream = iv_copy[:16]  # 使用完整的 IV 块作为密钥流
        plaintext += bytes([ciphertext[i * 16 + j] ^ keystream[j] for j in range(len(keystream))])

    return plaintext

if __name__ == '__main__':
    aes = AES()
    key = 0xECE60E4B00000000
    iv = os.urandom(16)

    # 自定义的明文字符串
    plaintext = "Hello, world! 你好，世界！"

    # 将明文转换为UTF-8编码的字节序列
    plaintext_bytes = plaintext.encode('utf-8')

    # 加密
    ciphertext = encrypt_OFB(plaintext_bytes, key, iv)

    # 解密
    decrypted_bytes = decrypt_OFB(ciphertext, key, iv)

    # 将解密后的字节序列转换为原始明文字符串
    decrypted_plaintext = decrypted_bytes.decode('utf-8')

    # 输出结果
    print("初始的明文：", plaintext)
    print("加密的密文：", ciphertext)
    print("解密的明文：", decrypted_plaintext)
