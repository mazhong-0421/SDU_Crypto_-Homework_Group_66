import hashlib
from ecdsa import SigningKey, VerifyingKey, SECP256k1


class HomomorphicMultiset:
    def __init__(self):
        self.private_key = SigningKey.generate(curve=SECP256k1)
        self.public_key = self.private_key.get_verifying_key()
        self.hashed_data = hashlib.sha256(b"").digest()

    def add(self, data):
        signature = self.private_key.sign(data, hashfunc=hashlib.sha256)
        self.hashed_data = hashlib.sha256(self.hashed_data + signature).digest()
        return signature

    def remove(self, data, signature):
        try:
            self.public_key.verify(signature, data, hashfunc=hashlib.sha256)
            signature_hash = hashlib.sha256(signature).digest()
            self.hashed_data = hashlib.sha256(self.hashed_data.replace(signature_hash, b"")).digest()
            return True
        except:
            return False

    def combine(self, other_multiset):
        combined_multiset = HomomorphicMultiset()
        combined_multiset.hashed_data = hashlib.sha256(self.hashed_data + other_multiset.hashed_data).digest()
        return combined_multiset

    def finalize(self):
        return self.hashed_data


# Example usage and verification of homomorphic property
multiset1 = HomomorphicMultiset()
data1 = b"data1"
signature1 = multiset1.add(data1)

multiset2 = HomomorphicMultiset()
data2 = b"data2"
signature2 = multiset2.add(data2)

is_valid1 = multiset1.remove(data1, signature1)
is_valid2 = multiset2.remove(data2, signature2)

print("Signature1 is valid:", is_valid1)
print("Signature2 is valid:", is_valid2)

combined_multiset = multiset1.combine(multiset2)
final_hash = combined_multiset.finalize()

print("Combined Multiset Hash:", final_hash.hex())

multiset1_hash = multiset1.finalize()
multiset2_hash = multiset2.finalize()
expected_combined_hash = hashlib.sha256(multiset1_hash + multiset2_hash).digest()

if final_hash == expected_combined_hash:
    print("Homomorphic property is verified.")
else:
    print("Homomorphic property verification failed.")
